package WildFarm;

public abstract class Mammal extends Animal{

    public Mammal(String animalName, String animalType, Double animalWeight, String animalLivingRegion) {
        super(animalName, animalType, animalWeight, animalLivingRegion);
    }
}
