package Word;

public class Command extends CommandImpl{

    public Command(String text) {
        super(text);
    }
}
