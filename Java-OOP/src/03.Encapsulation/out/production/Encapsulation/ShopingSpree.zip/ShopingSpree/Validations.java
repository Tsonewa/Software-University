package ShopingSpree;

public class Validations {

    public static final String INVALID_NAME = "Name cannot be empty";
    public static final String INVALID_COST =  "Money cannot be negative";
}
